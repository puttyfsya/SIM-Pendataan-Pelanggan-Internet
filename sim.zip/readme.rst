###################
Infly Register 
###################

Sistem Informasi Manajemen Pendataan Pelanggan

*******************
Release Information
*******************

Aplikasi ini realease pada tahun 2023 

*******************
Creadit
*******************

Developer : Putri Diana Hafsyawati

-  PHP version : 8.1.17 
-  URL PHP : https://www.php.net/

-  Codeigniter version : 3
-  URL PHP : https://codeigniter.com/userguide3/installation/downloads.html

-  Boostrap : 5
-  URL Boostrap :https://getbootstrap.com/docs/5.0/getting-started/introduction/

-  Desaign Web : Start Bootstrap SB Admin
-  URL Desaign Web : https://startbootstrap.com/template/sb-admin


