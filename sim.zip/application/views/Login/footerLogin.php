<script src="<?php echo base_url(); ?>assets/js/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/popper.js"></script>
<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/main.js"></script>
</body>
<footer>
   <br>
   <div class="footer clearfix mb-0 text-muted">
      <div class="fotlogin">
         <p align="center">2023 &copy; Infly Networks Create by Dimas&Putri</p>
      </div>
   </div>
</footer>

</html>